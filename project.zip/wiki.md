# Wiki

## Routen

- Startseite /
- Ticketpreise /tickets
- Crowdmap /map
- Gruppentickets /groups
- Tierwiki /wiki
- Einzelne Tierwiki Seite /wiki/{animal}
- Ticktes kaufen /buy

## Team Kommunikation

### 9.12.2024

Todos zu Board hinzugefügt

Arbeitsteilung:

- Startseite
- Ticketpreise
- Crowdmap
- Gruppentickets
- Tierwiki
- Einzelne Tierwiki Seite
- Burger Menü
- Ticktes kaufen
- Einheitlicher Header und Footer

Darauf geeinigt EJS zu nutzten um die Daten dynamisch anzuzeigen  
Meo macht Backend für EJS  
Nils koordiniert Projektbeginn

### 9.12.2024

Leon startet mit Index  
Meo erstellt grundlegendes Backend  
Nils Erstellt einheitlichen Header und Footer - Mal auf die Seite gelegt    
Nils beginnt Ticketseite  
Meo kümmert sich um Security-Probleme  

### 06.01.2025

Nils Ticketseite weiter  
Meo 404 Seite  
Meo Gruppenticktes Seite  
Leon versuchte Index zu verbessern
Leon wenig Informationen über getätigtes  
Nils Ticket-Seite fertig  
Tickets kaufen Seite begonnen   

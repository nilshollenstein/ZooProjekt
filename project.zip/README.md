# ZooProjekt

using NodeJS v22.12.0

### Dev

Install
```bash
npm run install-dev
```

Run
```bash
npm run dev
```



### Prod

Install
```bash
npm run install-prod
```

Run
```bash
npm run start
```

